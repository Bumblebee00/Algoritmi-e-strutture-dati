#include "main.h"

void MergeSort(att* v, int n);
void MergeSortR(att* v, int l, int r, att* helper);
void Merge(att* v, int l, int r, att* helper);