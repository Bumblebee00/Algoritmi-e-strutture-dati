#ifndef MAIN_H
#define MAIN_H
// atttività. ha un inizio e una fine
typedef struct { int inizio, fine; } att;

#endif