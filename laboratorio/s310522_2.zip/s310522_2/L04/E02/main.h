#define MAX 50

typedef struct {
    char codice[MAX];
    char nome[MAX];
    char cognome[MAX];
    char dataNascita[MAX];
    char via[MAX];
    char citta[MAX];
    int cap;
} Item;
