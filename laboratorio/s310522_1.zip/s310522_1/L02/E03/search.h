int *LinearSearch(BusRide **v, int n, char from[]);
int *BinSearch(BusRide **v, int l, int r, char from[]);