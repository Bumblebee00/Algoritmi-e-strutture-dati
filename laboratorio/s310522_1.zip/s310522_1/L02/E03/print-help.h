void print_ride(BusRide);
char *print_rideR(BusRide);
void print_rides(BusRide[], int);
void print_commands();
void print_ord_keys();